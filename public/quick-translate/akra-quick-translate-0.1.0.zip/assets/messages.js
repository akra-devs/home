var e=`akra-quick-translate:toggle`,t=`akra-quick-translate:toggle-active-tab`;export{e as n,t};
//# sourceMappingURL=messages.js.map